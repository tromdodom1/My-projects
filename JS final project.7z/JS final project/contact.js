function redirectToHome() {
    window.location.href = 'index.html'; 
}

function toggleDarkMode() {
    const body = document.body;
    body.classList.toggle("dark-mode");

    const isDarkMode = body.classList.contains("dark-mode");
    localStorage.setItem("dark-mode", isDarkMode);
}

const userPrefersDark = JSON.parse(localStorage.getItem("dark-mode"));
if (userPrefersDark) {
    document.body.classList.add("dark-mode");
}

const contactForm = document.getElementById("contactForm");

contactForm.addEventListener("submit", function (e) {
    e.preventDefault();

    fetch(contactForm.action, {
        method: contactForm.method,
        body: new FormData(contactForm),
        headers: {
            Accept: "application/json",
        },
    })
        .then(() => {
            alert("Your message was sent successfully.");
            // Optionally, you can reset the form after successful submission
            contactForm.reset();
        })
        .catch((error) => {
            console.error("Error:", error);
            alert("An error occurred while sending your message. Please try again later.");
        });
});

