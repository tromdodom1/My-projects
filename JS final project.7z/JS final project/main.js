

function redirectToHome() {
  window.location.href = 'index.html'; // Redirect to the Home page (index.html)
}

  // Function to toggle dark mode
  function toggleDarkMode() {
    const body = document.body;
    body.classList.toggle("dark-mode");

    // Store the user's preference in local storage
    const isDarkMode = body.classList.contains("dark-mode");
    localStorage.setItem("dark-mode", isDarkMode);
  }

  // Check local storage for user's preference
  const userPrefersDark = JSON.parse(localStorage.getItem("dark-mode"));
  if (userPrefersDark) {
    document.body.classList.add("dark-mode");
  }

